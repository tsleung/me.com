# Deep Space — documentation

A companion app for the puzzle game *The Message from Deep Space*. It reads
screenshots with Google's Gemini, accumulates what has been learned about the
alien language into a local knowledge base, and uses that to help work out
each new screen.

Read in this order:

| File | What it is |
|---|---|
| `architecture.md` | How the application works. Start here. Assumes no prior knowledge of the project. |
| `methodology.md` | How the application was *built* — the working method, written for someone curious about the process rather than the code. Includes an honest account of what went wrong. |
| `requirements.md` | What it does, what it deliberately does not do, and where it deploys. |
| `protocol.md` | The wire formats: the knowledge-base operation schema and the Gemini request/response contracts. |
| `process.md` | The decision log, including everything real play changed. |

Two things worth knowing before you read:

The app cannot read the game's state. Everything it knows is inferred from
pixels plus the player's own notes. That single constraint produced the whole
design.

And the failures are documented as carefully as the successes — including
several the test suite could not see, and one bug that the fix for another bug
created. `process.md` has the full record under "Findings from play".

Source lives in a private repository; the app itself is public at
<https://terranleung.com/apps/deep-space/>.
