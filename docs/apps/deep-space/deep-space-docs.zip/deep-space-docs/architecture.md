---
created: 2026-07-26
updated: 2026-07-27
---

# deep-space — architecture

A static, client-side PWA that helps a player solve the puzzle game
"The Message from Deep Space." This document explains the shape of the
system and why it is shaped that way. It assumes no prior exposure to
the project.

---

## 1. The problem

In the game (1973 setting) you are the mission Translator. A meteorite
is broadcasting; you reconstruct the alien language from the ground up
using math and science as the shared substrate — an alien numeral system
first, then arithmetic, then pattern, geometry, and broader scientific
concepts. It is **bidirectional**: you decode incoming transmissions
*and* compose outgoing replies, and a correct reply is what elicits the
next message. There are 30+ hours of content, so there are many levels.

The hard constraint for any assistant: **we cannot read the game's
state.** There is no save-file format we parse, no API, no DOM to
inspect. The only inputs available are

1. pixels — a screenshot of the game window, and
2. the player's own commentary — "this glyph changed when I clicked the
   left dial."

Everything else is inference. That single fact determines the entire
design. An assistant built on inference from noisy, partial observations
needs three things a chatbot does not give you: provenance (which
screenshot produced which belief), revisability (early theories in a
decoding puzzle are usually wrong), and replayability (when the model or
the prompt improves, you want to redo the reasoning without redoing the
game).

---

## 2. The load-bearing decision: map/reduce, readings as source of truth

The system is a map/reduce over screenshots.

- **map(screenshot, markers) → Reading.** One vision call per screenshot
  producing *structured perception only*, scoped to that screenshot.
- **reduce(readings, ops) → KnowledgeBase.** Cross-level beliefs: glyph
  meanings, numeral rules, mechanics, recipes for solved levels.

The decision that carries the architecture is: **readings are the source
of truth, and the knowledge base is a materialized view over an
append-only op log.** The model never rewrites the KB wholesale. It emits
*deltas* — `assert`, `revise(target)`, `retract(target)` — each carrying
its evidence screenshot hash. Local code validates them, the user
accepts or rejects each one, accepted ops append to the log, and the KB
is the deterministic fold over that log.

What this buys:

- **Provenance is structural, not bolted on.** Every belief traces to the
  op that created it and the screenshot that justified it.
- **"We thought X, level 9 disproved it, now Y" is expressible.** Stale
  beliefs are the real failure mode of a decoding assistant — they poison
  every downstream prompt — and here they are inspectable and
  retractable rather than baked into a blob of prose.
- **Re-reduce is a button, not a migration.** Better prompt, better
  model: re-fold the log, or re-run map over the stored screenshots and
  re-fold. That is the escape hatch for a KB that has gone bad.
- **The user adjudicates before anything lands.** A wrong belief costs
  one click to reject, not a debugging session.

### The invariant that makes it true: map must be KB-free

"Re-reduce is a button" is only true if a reading is a pure function of
`(image bytes, marker legend, model, prompt version)`. It is tempting to
show the reading call the accumulated glyph vocabulary — by level 5 a
naive pixel description looks nearly worthless on its own. Doing that
breaks everything: reading *n* would depend on the KB, which depends on
readings *0..n-1*. Replay would stop being a fold over cached data and
become an O(n) chain of nondeterministic vision calls — unreplayable,
uncacheable, and different every time you press the button.

So the map call is a hard invariant: **pure perception.** Verbatim
on-screen text, glyph shapes and positions, layout, affordances, colors,
counts. No interpretation. All interpretation lives in the answer call,
which *does* see the KB, and which is cheap to re-run because it takes no
image.

The payoff is the reading cache: readings are keyed by
`sha256(png) | model | promptVersion`, so re-reduce costs **zero vision
calls**, and bumping `PROMPT_VERSION` invalidates the whole cache by
construction.

---

## 3. Data flow, end to end

Per level:

```mermaid
flowchart TD
    A["Paste / drop / getDisplayMedia<br/>PNG blob"] --> B["hashBlob → SHA-256"]
    B --> C["putShot: blob + thumb + dims<br/>IndexedDB 'shots'"]
    C --> D["Annotate: numbered markers + per-marker notes<br/>+ free-text level note"]
    D --> E["burnMarkers → annotated PNG<br/>markerLegend → text"]

    E --> F{"getReading(hash, model, promptVersion)<br/>cached?"}
    F -- hit --> H["Reading"]
    F -- miss --> G["MAP CALL — image + legend only<br/>NO knowledge base<br/>responseSchema = READING_SCHEMA"]
    G --> H
    H --> I["putReading: cache under hash|model|promptVersion"]

    J["foldOps(allOps) → KB Map"] --> K["serializeKb → kbText<br/>(empty string if 'run without KB')"]
    I --> L["ANSWER CALL<br/>reading + kbText + notes + level<br/>responseSchema = ANSWER_SCHEMA"]
    K --> L

    L -. "SSE deltas" .-> LT["Live transcript<br/>reasoning shown apart from the answer"]
    T["Complaints for this screen<br/>all of them, oldest first"] --> L
    L --> M["summary · hypotheses · proposedReply<br/>proposedMove · ops[] · code?"]
    M --> U["Rejected? add a complaint → T"]
    M --> N["validateOps(ops, kb)<br/>accepted / rejected / rewritten"]
    N --> O["User accepts or rejects each op"]
    O --> P["appendOps → IndexedDB 'oplog' (append-only)"]
    P --> J

    M --> Q["Code panel"]
    Q --> R["runInSandbox — iframe, opaque origin"]
    Q --> S["Gemini server-side codeExecution"]
```

Two things to notice. First, the only loop in the diagram is
op-log → fold → KB → next answer call; nothing else accumulates state.
Second, the map call has exactly two inbound edges — image and legend —
and that is the whole of invariant 0.

The follow-up path is deliberately *not* a chat. When an answer is wrong,
the player writes what was wrong with it; that complaint joins a list held
against the screen, and **every complaint for that screen is sent with
every retry**, oldest first. Sending only the newest one lets the model fix
that and regress on an earlier one it can no longer see — nothing else
remembers them, because there are no conversational turns. One shot means
no turns, not one HTTP request.

The answer call streams (`:streamGenerateContent?alt=sse`) so the reply can
be watched as it arrives. Reasoning parts (`thought: true`) are rendered
separately and, critically, **excluded from the text handed to the JSON
parser** — reasoning mixed into structured output is exactly what makes
parsing fail.

---

## 4. Module layout

No build step, no bundler, no npm dependency in the app. Native ES
modules, loaded with `<script type="module">`. All files live directly
under `docs/apps/deep-space/`.

| File | Role |
|---|---|
| `kb.js` | Pure op validation, fold, contradiction detection, KB serialization. DOM-free, node-importable, unit-tested. |
| `db.js` | IndexedDB wrapper — `shots`, `readings`, `oplog`, `analyses`, `settings`; storage estimate, persist request, export/import bundle. |
| `image.js` | Content hashing, thumbnails, burning numbered markers into a copy of the PNG, marker legend text, base64 encoding. |
| `prompts.js` | `PROMPT_VERSION`, the two response schemas, and the two prompt builders. Pure, node-importable, unit-tested. |
| `gemini.js` | The only network module: `listModels`, `generate`, `mapScreenshot`, `answerLevel`. Throws human-readable errors. |
| `sandbox.js` / `sandbox.html` | Sandboxed-iframe execution of generated code, with a hard timeout and captured logs. |
| `debug.js` | Assembles the exportable debug report and redacts secrets from it. Pure, node-importable, unit-tested — that is the whole reason it is not inline in `app.js`. |
| `app.js` + view modules | UI: capture, level list, annotation, settings, analysis, op adjudication, KB view. |
| `__tests__/` | `node --test` over the pure modules only. No DOM. |

`kb.js` and `prompts.js` are DOM-free on purpose: the parts worth testing
(the fold, op validation, duplicate detection, the KB-free-map property)
are exactly the parts that can be tested without a browser.

---

## 5. Storage

IndexedDB, holding `Blob`s directly — never base64 strings, which cost
+33% size and a pointless string coercion. Database version 2, five
object stores: `shots` (keyed by content hash), `readings` (keyed by
`hash|model|promptVersion`), `oplog` (auto-increment, append-only),
`analyses` (keyed by shot hash — the last answer for a level, so a reload
does not discard pending un-adjudicated ops), and `settings` (API key,
model name, toggles).

**Why lossless PNG.** The obvious move is a downscale-and-WebP pipeline —
vision models re-tile the image anyway, and it would cut storage, upload
latency, and cost together. It is wrong here. The signal we need is
thin-stroke glyph shape, which is precisely what lossy compression
destroys first, and a misread stroke propagates into a wrong belief that
then seeds every later prompt. We store and send the original PNG. The
only derivative is a ~320px thumbnail for the level list.

**Why `navigator.storage.persist()`.** Unpersisted origin data is
evictable under disk pressure — the browser can delete a session's worth
of screenshots and the entire op log without asking. Installed PWAs are
granted persistence automatically in Chrome, which is the actual reason
this is a PWA at all; there is no offline caching and no service-worker
strategy beyond installability.

Storage usage is surfaced in settings via `StorageManager.estimate()`
("N screenshots, X MB of ~Y GB"). Storage anxiety is what makes people
stop using an app like this. And browser storage is not a backup, so
export/import of a JSON bundle (images base64-encoded, plus the op log
and settings **minus the API key**) is non-negotiable.

---

## 6. Two code-execution paths, and where the real boundary is

The model can propose code — an encoder/decoder pair, a brute-force
search over numeral bases, a validator. Two ways to run it, selectable
per run:

**Local (primary).** Generated JavaScript executed in an
`<iframe sandbox="allow-scripts">`. Omitting `allow-same-origin` gives
the frame an **opaque origin**: it cannot open our IndexedDB, cannot read
our localStorage, cannot touch the host DOM. The host posts
`{ code, input }` in, receives `{ ok, result, logs, error }` back, and
enforces a hard timeout by *removing the iframe* — an infinite loop
cannot be interrupted from the outside.

The obvious-looking alternative, a Web Worker, is **not** a sandbox. A
same-origin worker can `fetch`, and it can open IndexedDB and read both
the knowledge base and the user's API key. "No DOM, no network" is not
true by default, and GitHub Pages cannot set CSP response headers to
make it true. The iframe attribute is enforced by the parser rather than
by a header, which is why it works on static hosting.

**Server-side (secondary).** Gemini's built-in code execution tool
(sandboxed Python, zero sandboxing work for us, good at one-shot brute
force). It only sees what is in the prompt. Note the API constraint:
`tools: [{ codeExecution: {} }]` cannot be combined with
`responseSchema`, so that path drops the schema, instructs JSON in the
prompt text, and parses leniently.

Both paths exist partly to watch them diverge on the same puzzle. Cut
from v1: the *persistent solver library* — storing solvers across levels
and re-running them. Stored code rots without a captured
input/expected-output case re-run before reuse, and a folder of rotting
solvers is worse than nothing.

---

## 7. The "run without KB" experiment

The entire premise of the app is that the knowledge base **compounds** —
that having decoded levels 1–10 makes the assistant materially better at
level 11 than a cold model looking at the same screenshot.

That is a hypothesis, and nothing else in the design tests it. So there
is a toggle: run the answer call with `kbText = ''`. Same screenshot,
same reading (it's cached, and it's KB-free, so it is *literally the same
reading* — this only works because of invariant 0), same notes, empty
knowledge base.

After ten levels, compare. If the with-KB answers aren't better, the
op log, the validation, the contradiction queue, and the adjudication UI
are all elaborate machinery around a null result — and that is worth
knowing early. Five lines of code to find out.

---

## 8. What playing the game changed

The design above survived first contact largely intact. What did not was
the *prompting*, and every correction below came from a real session with
the game open beside the app — none from the test suite, which stayed
green throughout.

**Separate the signal from the story.** The first reading schema had one
`screenText` field. On a screen showing an OUTPUT panel of frequency
values *and* a crew member exclaiming "Ain't that splendid! Another new
transmission!", the loudest text was the flavour — and the answer came
back "This screen does not currently ask for a reply. The player is in a
narrative dialog segment." The schema now leads with
**`transmissionContent`** (the signal, verbatim, in display order) and
**`narrativeText`** (crew chatter, explicitly never puzzle data), and the
answer prompt is told how to weight them. This was a *structural* fix,
not a stronger instruction, and that is why it worked.

**A model given an escape hatch will find it.** An earlier round had
already forbidden punting; the model simply discovered a new excuse
("narrative dialog segment") for the same behaviour. Closing one hatch
relocates the behaviour rather than ending it, so the rule is now
absolute: always commit to a best candidate reply with a confidence, and a
closed composer, a dialogue box and a cutscene overlay are named as
non-reasons.

**Assume interface fluency.** The player has sent dozens of replies. Early
answers spent themselves on "click the green RESPOND button", which is the
one thing he already knows. `proposedReply` is now the primary field and
comes first in the schema; `proposedMove` was demoted to *what must happen
before the reply can be settled* and is expected to be empty when it is
already determined.

**`subject` must name a concept, never a value.** Contradictions are found
by matching `kind` + `subject`. The model had been filling `subject` with
the *value* — "1420405753", "1420406008" — so each new number became its
own subject and nothing ever collided. A real knowledge base was found
holding four mutually incompatible beliefs about the hydrogen line
frequency, all at *high* confidence, with exactly one pair detected. The
schema now demands a stable lowercase concept name and explains the
consequence.

**Guards can manufacture the failure they were built to catch.** A
`maxOutputTokens` cap added as a runaway backstop starved the answer,
because for thinking models the reasoning is drawn from the same budget.
The truncated output degenerated into repetition, which then tripped the
repetition detector. The detector was right; it was firing on a symptom
the cap had created.

**Degeneration also happens inside a single JSON string.** A `revise` came
back with ~4,000 characters of repeated word salad in `reason` and no
`statement`. The stream-level repetition guard cannot see that — the text
is varied word salad, not exactly periodic — so `kb.js` caps every field
at 600 characters. This matters more than it looks: a belief is re-sent in
every later prompt, so one degenerate field costs tokens forever.

---

## 9. Operating it

**Three run buttons, because they cost different things.** *Analyze* reads
the picture if needed, then answers. *Answer again, same picture* reuses
the stored description — one answer call, no vision call; the right button
after adding a note. *Read the picture again* returns to the screenshot and
re-describes it — one vision call, no answer; the right button after the
prompts change.

**Rebuilding.** The screenshot is the only thing that cannot be
regenerated. Readings are stamped with the prompt version and model that
produced them, so a `PROMPT_VERSION` bump is *visible* rather than merely
implied by a cache miss: the level view flags a stale reading and Settings
reports how many screens are behind, with a bulk re-read that skips those
already current and can be stopped part-way. Bulk re-*answer* is
deliberately absent — it would flood every level's pending-op queue at
once.

**The debug report.** One file per screen carrying the exact prompt text
for both calls, the raw reply and any reasoning, the parsed answer, the
knowledge base as it stood, the validator's verdicts, the complaints sent,
recent errors and the run settings. The picture is opt-in (~31 KB with,
~21 KB without). The API key is stripped by field name *and* by pattern,
because Google echoes the key back inside some error bodies and those sit
in the captured error log.

---

## 10. Known limits

- **Perception is the ceiling.** If the vision model misreads a glyph,
  every downstream belief is wrong. There is no oracle to check against.
  Marker annotations exist to give the player a way to correct
  perception, but they are advisory.
- **The KB is only as good as the adjudication.** The user accepts ops. A
  user who clicks accept on everything gets a knowledge base full of
  confident nonsense.
- **Contradiction detection is structural, not semantic.** It catches
  *same kind + same subject* with differing statements, and nothing else.
  This has already bitten in practice: when the model put values in
  `subject`, four incompatible beliefs about one quantity coexisted at
  high confidence and only one pair was flagged. The prompt now demands
  concept-named subjects, which prevents new occurrences — but it does not
  repair beliefs already recorded the old way, and it will never catch a
  contradiction expressed across genuinely different subjects.
- **Duplicate detection is normalized-string equality.** Paraphrases slip
  through. Duplicate growth is slowed, not eliminated.
- **Context is fine now, not forever.** A few hundred belief statements
  fits whole in a Flash window. No embeddings, no retrieval, until it
  actually overflows. The serializer takes `{ includeLow, maxEntries }`
  and the cap is wired to a user-editable `kbMax` setting (default 120);
  the answer panel reports "sent N of M remembered entries" so silent
  truncation is visible rather than inferred.
- **Content-hash dedupe rarely fires.** Cursor pixels differ between
  otherwise-identical shots. The hash exists as the reading cache key,
  which is its real job; dedupe is incidental.
- **API key exposure.** The key sits in the user's own IndexedDB and is
  visible in devtools on their own machine. Mitigation is
  console-side: restrict the key to the Generative Language API and an
  HTTP referrer. Blast radius is the user's own quota.
- **No verification loop.** The app cannot tell whether a proposed reply
  was correct. The player tells it, in the next level's notes or as a
  complaint on the answer.
- **The suite cannot see the failures that matter.** Every prompting
  defect in §8 was invisible to 152 passing tests and a green browser
  suite. Unit tests pin the fold, the validator and the redaction rules —
  they say nothing about whether an answer is any use. That is what the
  debug report and the run-without-KB comparison are for.
