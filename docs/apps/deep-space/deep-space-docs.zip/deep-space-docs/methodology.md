---
created: 2026-07-26
updated: 2026-07-27
---

# How this application is being built

*Written for a reader who is curious about the process rather than the code.
It reconstructs the method from the actual prompt log
([`prompts.md`](prompts.md)) rather than from anyone's memory of it — the
transcript is the evidence, and it disagrees with the story people usually
tell about working with an LLM.*

---

## The short version

An engineer described a problem, an LLM proposed a design, the engineer
corrected it, a **second, different LLM was brought in specifically to attack
the design**, the engineer adjudicated the disagreement between them, and only
then was any code written — by a fan-out of parallel agents working against a
frozen interface contract.

Roughly four rounds of conversation preceded the first line of application
code. That is the method. Everything below is detail.

---

## The five moves that did the work

### 1. Lead with what cannot be known

The opening message did something unusual. Before describing a single
feature, it fixed a constraint:

> we will be able to do this model free because we don't know how the game is
> storing things

That sentence is the entire architecture. Because the game's internal state
is unreadable, every fact about the game has to be *inferred from pixels plus
the player's own commentary*. That single constraint eliminates whole
categories of design — no save-file parsing, no memory reading, no API — and
forces the interesting question: if you can only ever look at a picture, how
do you accumulate reliable understanding across dozens of levels?

Most feature requests describe a desired output. This one described an
epistemic limit. Designs that start from a limit tend to survive contact with
reality; designs that start from a wish list tend not to.

### 2. State technical picks as proposals, not orders

The first message named specific technology: browser localStorage, a PWA,
Gemini as the model, hosting on a personal domain. Every one was phrased as a
hypothesis — "I was thinking," "I was debating," "what do you think?"

That framing mattered, because **three of those initial picks were wrong**:

- **localStorage** holds about 5 MB and only strings. A handful of
  screenshots exceeds it. The right mechanism was IndexedDB, which stores
  image data directly and gets a share of free disk.
- **"host it publicly but don't link it from the homepage"** was a privacy
  mechanism that doesn't provide privacy. Unlinked URLs leak through browser
  history, share links, and public file listings. (This one was half-wrong in
  an instructive way — see move 3.)
- **One model call per level** was the implicit assumption. It turned out
  that splitting into two calls — one that only *looks*, one that only
  *reasons* — is what makes the whole system replayable. More on that below.

None of those corrections caused friction, and the reason is structural: a
proposal can be corrected, an instruction has to be defied. An engineer who
issues orders to an LLM gets compliance. An engineer who floats hypotheses
gets a critic. The second is worth far more, and the difference is purely in
the phrasing.

### 3. Separate the factual correction from the concession

The second message contains a small masterclass in one sentence:

> pardon, me.com IS terranleung.com, we don't serve anything from
> terranleung.com repo. Use the existing capabilities we currently have, you
> are right to flag it

The LLM had made a factual error about how the deployment works *and* raised
a legitimate policy objection. These were tangled together. The response
untangled them: corrected the fact, conceded the objection, moved on. No
defensiveness about the mistaken half, no re-litigating the correct half.

This is harder than it sounds, and it is where most human–LLM collaboration
degrades. When a model gets a fact wrong inside a criticism, the natural
human move is to dismiss the whole criticism. The natural LLM move, when
corrected, is to over-apologize and abandon the valid point too. Both
failures were avoided in one line.

### 4. Bring in an adversary before committing

Before any code:

> I think that's all the questions, we can start building. get a fable review
> before we proceed

A *different* model — a different architecture, different training,
different failure modes — was pointed at the design document with
instructions to find what was wrong rather than to confirm what was right.

It found four things, and they were not cosmetic:

- The claim that the system could cheaply rebuild its own understanding from
  scratch was **false as designed**, and would have failed silently around
  the fifth level.
- The knowledge base had no way to notice that a new fact **contradicted an
  old one**. Both would simply sit there, and both would be fed to the model
  forever. This is the failure that would have quietly poisoned everything
  around level 20 — long after anyone would think to look for it.
- The plan to compress screenshots would have **destroyed the exact signal
  the app exists to read** — thin-stroke alien glyphs are precisely what
  lossy image compression discards.
- A security property the design claimed — that generated code would run in
  an isolated environment — **was simply not true** of the mechanism chosen.

Three of those four are the kind of bug that does not announce itself. It
would not crash. It would just get slowly, unfalsifiably worse, and the
natural conclusion would have been "I guess AI isn't good at this game."

The general principle: **the cheapest place to find an architectural error is
in a document, and the most reliable way to find one is to hand it to
something that did not write it.** A model reviewing its own design grades
its own homework. A different model has no investment in the answer.

### 5. Adjudicate rather than defer

The review was not simply obeyed. Two of its recommendations were overridden,
both because it had over-corrected:

- It recommended **cutting the ability to run generated code locally**. But
  its actual finding was that the *stated safety property* was false, not
  that the feature was unworkable. A correct isolation mechanism exists. The
  feature stayed; the mechanism was fixed. A stated preference should not be
  overturned by a review when a correct implementation is available.
- It recommended **cutting screenshot annotation**. But its own suggested
  replacement was better than the original design — draw numbered markers
  directly onto the image so the model can actually see what "point 2" refers
  to, rather than passing coordinates it cannot perceive. The feature stayed,
  implemented the reviewer's way.

Its repo-specific claims were also **checked rather than trusted**, and one
was partly wrong. This matters: a confident, well-written critique from a
capable model is still a claim, not a finding. Two of the six items it
asserted about the project's tooling were already handled.

---

## The one idea that came from the human

Worth isolating, because it is the load-bearing contribution and it did not
come from the machine:

> This continues to have the shape of a map (per level) and reduce (knowledge
> we have up until the current we're at) which we can feed back to the LLM.

*Map* and *reduce* are borrowed from data processing. **Map** applies the same
operation independently to every item. **Reduce** folds all those results into
one accumulated answer.

Applied here: each screenshot is *mapped* to a plain description of what is on
screen. All descriptions so far are *reduced* into a single accumulated
understanding of the alien language. That understanding is fed back in when
looking at the next level.

The LLM had proposed something functionally similar but had described it as a
"knowledge base" — a vaguer, softer idea. Naming it map/reduce imported a set
of hard constraints that the vague version lacked, and those constraints are
what the reviewer was later able to test against. Specifically: for a reduce
to be re-runnable, the map steps must be *independent of each other*. That is
exactly the invariant the review discovered was being violated — and it was
only discoverable *because the idea had a precise name*.

**Borrowing a precise idea from another field gives you its theorems for
free, including the ones that tell you your design is broken.** That is what
happened here.

---

## The design mirrors the process

The most interesting property of this project is one nobody planned.

The application works like this: it looks at a screenshot and records only
what is *literally visible*, with no interpretation. Separately, it reasons
over everything recorded so far and proposes new beliefs about the alien
language — each tagged with which screenshot justifies it. A human accepts,
rejects, or overrides each proposed belief before it becomes part of the
knowledge base. Beliefs can be revised or retracted later when a new level
contradicts them, and the full history is kept so the whole understanding can
be rebuilt from the original observations.

That is also, precisely, how this conversation has been run. Observations are
kept separate from interpretations. The model proposes; the human adjudicates.
Every accepted decision is recorded with the reasoning that produced it,
including the rejected alternatives. Nothing is taken on authority, and any
conclusion can be traced back to what justified it.

The project's notes directory is to this conversation exactly what the app's
knowledge base is to the game. Neither was designed to imitate the other. They
converged because the underlying problem is the same: **how do you accumulate
reliable understanding from an unreliable source, over a long time, without
the errors compounding?**

The answer, in both cases: keep raw observation separate from interpretation,
attach evidence to every belief, let beliefs be revised rather than
overwritten, and keep enough history that you can rebuild from scratch when
you discover you were wrong.

---

## Where this account could be wrong

The person who ran this process asked, explicitly, that his own bias be
corrected here. Four honest caveats:

**1. The likely misdescription runs in both directions.** The easy summary is
"I asked an AI to build an app," and the transcript does not support it — the
constraint, the map/reduce framing, the decision to keep local execution
against expert advice, and the call to bring in a reviewer at all were human
contributions, and they are the decisions the design rests on. But the
opposite summary — "the AI wrote the whole thing" — is equally unsupported.
The accurate description is narrower and less quotable: *the human supplied
the constraints and the adjudication; the machines supplied implementation,
research, and criticism.* Neither half works alone. The design would have
been broken without the reviewer, and there would have been nothing to review
without the human framing.

**2. The independent review was filtered through the thing being reviewed.**
The reviewer's report went to the LLM being reviewed, which summarized it,
decided which findings to accept, and overrode two of them — before the human
saw the raw text. The overrides look correct and the raw report was preserved
so it can be checked. But calling this a fully independent check is too
generous. A genuinely independent review would have been read first by the
person, not by the party with an interest in the verdict.

**3. Decisiveness laundered one open question into a settled one.** The
model name `gemini-3.5-flash` was marked "confirmed" in the conversation. The
LLM could not verify that this identifier exists, and said so. Confirmation
closed the question anyway. Decisiveness is generally an asset in this process
— it is what kept four rounds from becoming twenty — but it has this specific
failure mode: a confident answer and a verified answer are indistinguishable
in a transcript. A safeguard was built in (the app checks the model name
against the live list of available models and shows a plain-language error),
but the pattern is worth watching, because it will not always be caught.

**4. Documentation confidence is not working-software confidence.** This
section originally said there were six documents describing the application
and zero lines of it that a human being had run. That is no longer true, and
what happened next is the most useful thing in this document.

The app was played with. It worked — and it was, at first, useless. It spent
its answers telling an experienced player which button to press. It refused
to solve a puzzle whose numbers were plainly on screen, on the grounds that a
dialogue box was open. It filled the knowledge base with facts about buttons.
It quietly accumulated four mutually contradictory beliefs about one physical
constant, all marked *high confidence*, and the contradiction detector — a
feature specifically designed to catch exactly that — reported one problem
pair out of six.

**None of this was visible to the tests.** A hundred and fifty-odd unit tests
and a full browser suite stayed green through every one of those failures.
They pin the things that can be pinned: the fold is deterministic, the
validator drops nothing silently, the API key never reaches the debug report.
None of that has any bearing on whether an answer is worth reading.

So the honest revision to the claim: the *design* process described above was
sound, and the review gate genuinely caught defects that would have been
expensive later. But every failure that made the app unhelpful in practice was
found by a person using it, usually within a minute, and none by the
machinery built to find failures. The design work bought correctness. Only
use bought usefulness. They are not substitutes, and the second is much
cheaper than it looks — a screenshot and one sentence of complaint located
problems that no amount of further review would have.

The comparison that would settle whether the knowledge base earns its
existence — the same levels answered with it and without it — still has not
been run.

---

## If you want to try this yourself

Five things, in rough order of how much they matter:

1. **Say what you can't know, not just what you want.** Constraints generate
   better designs than requirements do.
2. **Phrase technical choices as guesses.** You will be corrected instead of
   obeyed, and you want to be corrected.
3. **Have a second model attack the plan before anyone writes code.** Not
   "review this" — *find what's wrong with this*. Different model, different
   blind spots.
4. **Don't just accept the critique.** Check its factual claims, and override
   it where it has over-corrected. It is a capable adversary, not an
   authority.
5. **Write down the reasoning, not just the decision** — including what you
   rejected and why. Six weeks later, the decision is unrecoverable without
   it, and you will re-litigate it from scratch.
6. **Use the thing, early, for real.** Every defect that made this app
   unhelpful was found in the first hour of actually playing with it, and
   none by the tests. Reviews and test suites establish that software is
   correct. Only use establishes that it is worth anything, and the two
   failure modes barely overlap.
7. **When it fails, fix the structure rather than adding instructions.** The
   worst answer this app produced was fixed not by telling the model to try
   harder, but by splitting one field in a schema into two — signal in one,
   story in the other. Instructions get routed around; structure does not.

And the meta-point: none of this is specific to building software. It is a
method for accumulating trustworthy understanding from a fast, fluent,
confidently-wrong source. Which is also, not coincidentally, the exact problem
the application itself was built to solve.
