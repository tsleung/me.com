---
created: 2026-07-26
updated: 2026-07-27
---

# deep-space — wire protocol

Three wire formats, all local except the Gemini one:

- **A.** The knowledge-base op schema — what the model emits, what local
  code accepts, and what the fold produces.
- **B.** The Gemini request/response contracts — reading schema, answer
  schema, and the `codeExecution` / `responseSchema` mutual exclusion.
- **C.** The sandbox `postMessage` protocol.

---

## Invariant 0 — the map call is KB-free

**Rule.** The screenshot-reading ("map") request carries exactly two
things: the annotated PNG and the marker legend text. It never carries
the knowledge base, prior vocabulary, prior readings, or any
interpretation. `mapPrompt()` does not accept a KB argument, and that is
enforced by its signature and by a unit test.

**Why it is protocol-level and not stylistic.** A reading is only
replayable if it is a pure function of `(image bytes, legend, model,
prompt version)`. The moment the reading step sees prior glyph
vocabulary, readings stop being independent: reading *n* depends on the
KB, which depends on readings *0..n-1*, and "re-reduce" degrades from a
deterministic fold over cached data into an O(n) chain of
nondeterministic vision calls that cannot be replayed and cannot be
cached. Keeping map pure is what buys the cache key below and the
re-reduce button in feature 10.

**Consequence — the reading cache key.** Readings are stored under
`hash + '|' + model + '|' + promptVersion`, where `hash` is the SHA-256
of the stored PNG. Bumping `PROMPT_VERSION` in `prompts.js` invalidates
every cached reading by construction. Re-reduce over an unchanged prompt
version costs **zero vision calls**.

All interpretation — glyph meanings, arithmetic hypotheses, proposed
moves, proposed replies, proposed ops — happens in the *answer* call,
which does see the KB.

---

## A. Knowledge-base op schema

### Ops (authored by the model, validated locally)

Three shapes. `level` is the level number the op was proposed on;
`evidence` is an array of shot hashes.

```js
{ op: 'assert',  id, kind, subject, statement, confidence, evidence: [shotHash], level }
{ op: 'revise',  target, statement, confidence, evidence: [shotHash], level, reason }
{ op: 'retract', target, reason, level }
```

- `kind` ∈ `BELIEF_KINDS` = `numeral | glyph | operator | grammar |
  mechanic | concept | recipe`.
- `confidence` ∈ `CONFIDENCES` = `low | medium | high`.
- `subject` is the thing the belief is about — a glyph, a mechanic name,
  a level recipe key. `statement` is free text.

A coarse `kind` plus a free-text `statement` is deliberate. The game
spans numerals, arithmetic, geometry, and reply composition; a tighter
schema would have to be guessed before we know what the later levels
need, and guessing wrong costs a migration.

### Belief record (derived — never authored directly)

```js
{ id, kind, subject, statement, confidence,
  status: 'active' | 'retracted',
  evidence: [shotHash],
  supersedes: string | null,
  level, seq }
```

`seq` is the op-log sequence number that last touched the belief;
`supersedes` chains a revised belief back to the id it replaced.

### The op log

Append-only, `autoIncrement` keyed, one entry per **accepted** op:

```js
{ seq, level, shotHash, op, source: 'model' | 'user', acceptedAt }
```

Rejected ops never enter the log. `source: 'user'` covers manual
retractions from the KB view and contradiction adjudications.

### Validation rules (`validateOps(ops, kb)`)

Returns `{ accepted, rejected, rewritten }`. The model is not trusted to
address the KB correctly, so:

| Case | Handling |
|---|---|
| Malformed op (bad `op`, unknown `kind`/`confidence`, missing required field) | `rejected`, reason names the field |
| `revise`/`retract` whose `target` is not an **active** belief in the KB | **Never silently dropped.** Rewritten into a proposed `assert` and recorded in `rewritten[]` as `{from, to, reason}` |
| `assert` whose `kind`+`subject` matches an active belief and whose `normalizeStatement(statement)` is equal to it | `rejected` with reason `'duplicate'` |

The unknown-target rule exists because the model *will* hallucinate ids.
Dropping those ops loses a real observation; accepting them corrupts the
fold. Rewriting to an assert keeps the observation and puts the decision
in front of the user.

The duplicate rule exists because the model *will* re-assert facts it
already asserted, once per level, forever — linear duplicate growth is
what poisons prompts around level 20, before context length ever
becomes the binding constraint.

`normalizeStatement(s)` lowercases, collapses whitespace, and strips
punctuation. It is the comparison key for duplicates and for
contradictions; it is never persisted.

### Fold and contradictions

`foldOps(ops)` → `Map<id, Belief>`. Pure, deterministic, dependent only
on array order. `assert` inserts, `revise` replaces `statement` /
`confidence` and sets `supersedes`, `retract` flips `status` to
`'retracted'` (the record stays — retraction is history, not deletion).

`detectContradictions(kb)` returns
`[{ subject, kind, beliefs: [Belief, Belief] }]` for **active** beliefs
sharing `kind`+`subject` with differing normalized statements. A bare
fold cannot notice that level 12 contradicts level 4 — both simply
coexist in the KB and both go into every subsequent prompt. The
contradiction queue is where the user picks a winner; the loser is
retracted with `source: 'user'`.

`serializeKb(kb, { includeLow = true, maxEntries })` produces the compact
plain-text block sent in the answer prompt. `maxEntries` is supplied from
the user-editable `kbMax` setting (default 120); entries are ranked by
confidence then recency, and the UI reports how many of the remembered
entries were actually sent, so truncation is never silent. `kbStats(kb)`
reports `{ total, active, retracted, byKind, contradictions }`.

The block is **line-oriented — one belief is exactly one line** — and the
answer prompt tells the model that `target` may only be an id appearing in
it. Nothing upstream forbids a multi-line `statement`, so `serializeKb`
collapses whitespace in `subject` and `statement` before emitting the line.
Without that, a statement containing `"\n# glyph\ngly-9 (high) circle: …"`
renders as an extra kind heading plus a belief whose id does not exist, and
the model aims `revise`/`retract` at it — every one of which the validator
then rejects as `unknown-target`. Flattening matches `normalizeStatement`,
which already squeezes whitespace for duplicate and contradiction keys.

`foldOpsDetailed(ops)` returns `{ kb, skipped: [{ index, op, reason }] }`;
`foldOps` delegates to it. An op the fold cannot apply — a `revise` or
`retract` naming a target that is absent or already retracted — is
reported in `skipped`, never dropped in silence. `remapOpIds(ops, tag)`
namespaces a foreign op log on import: belief ids are positional, so an
imported log's `revise`/`retract` targets would otherwise re-aim at
whichever local belief happens to occupy that id.

`nextBeliefId(kb, kind)` derives ids from KB contents, not from
`Math.random` or `Date.now`, so folds are reproducible under test.

---

## B. Gemini contracts

Endpoint: `https://generativelanguage.googleapis.com/v1beta/...`, called
directly from the browser (CORS is fine). The key is the user's own,
stored in IndexedDB, sent nowhere but Google.

`listModels(apiKey)` GETs `v1beta/models` and returns vision-capable
`generateContent` model ids. It backs the settings "check model" button —
a wrong model id is the likeliest first-run failure and must surface as
a UI message, not a console 404. Errors from `generate()` are thrown with
human-readable text suitable for direct display (bad key, unknown model,
quota exhausted, network failure).

Two calls per level. "One shot" means *no conversational turns*, not one
HTTP request; splitting perception from interpretation is materially
more reliable on Flash.

### Call 1 — map (perception)

Request parts: `[ { inline_data: { mime_type: 'image/png', data } },
{ text: mapPrompt(markerLegendText) } ]` with `responseSchema =
READING_SCHEMA`. No KB. No prior readings.

Reading shape:

```js
{
  screenText: [string],                              // verbatim, as rendered
  glyphs: [{ shape, position, count }],              // described, not interpreted
  layout: string,
  affordances: [string],                             // buttons, dials, slots
  colors: [string],
  observations: [string]
}
```

The prompt instructs pure description: verbatim text, glyph shape and
position, layout, affordances, colors, counts. No guesses at meaning.

### Call 2 — answer (interpretation)

Sent to `:streamGenerateContent?alt=sse`. Server-sent events are parsed
line by line and the deltas accumulated into the same payload shape the
non-streaming endpoint returns, so everything downstream is identical
either way.

`generationConfig.thinkingConfig = { includeThoughts: true }` is requested.
Parts carrying `thought: true` are surfaced separately in the UI and
**excluded from the text handed to the JSON parser** — reasoning mixed
into structured output is precisely what makes parsing fail. A 400 whose
message mentions the thinking config retries once without it rather than
failing the request.

`standingNotes` is a persistent player-authored block injected in its own
section ahead of the per-level note, and stated in the prompt to outrank
the model's own habits.

Request: `answerPrompt({ readingJson, kbText, userNote, level,
allowCodeExec })` with `responseSchema = ANSWER_SCHEMA` (see the
exception below). `kbText` is `serializeKb(...)` output, or the empty
string when the **run without KB** toggle is on.

Answer shape:

```js
{
  summary: string,
  hypotheses: [{ claim, confidence, rationale }],
  proposedMove: string,
  proposedReply: string,                             // the outgoing alien message
  ops: [Op],
  code: { language, source, purpose, expectedShape } | null
}
```

`proposedReply` is first-class because the game is bidirectional — a
correct reply is what elicits the next transmission.

### codeExecution vs. responseSchema — mutually exclusive

**Known API constraint.** `tools: [{ codeExecution: {} }]` cannot be
combined with `responseMimeType: 'application/json'` /
`responseSchema`. Therefore, when `allowCodeExec` is true:

- omit `responseSchema` entirely,
- instruct the JSON shape in the prompt text instead,
- parse leniently on return: strip markdown fences, then find the
  outermost balanced `{ … }`,
- surface executable-code parts and their execution outputs alongside
  the parsed answer.

When `allowCodeExec` is false, the schema is enforced server-side and
parsing is strict. The lenient parser is the fallback path, not the
default one.

---

## C. Sandbox postMessage protocol

`runInSandbox(code, input, { timeoutMs = 3000 })` →
`{ ok, result, logs: [], error }`.

The host creates an `<iframe sandbox="allow-scripts">` pointing at
`sandbox.html`. Because the sandbox attribute omits `allow-same-origin`,
the frame gets an **opaque origin**: it cannot reach our IndexedDB
(the KB *and* the API key), cannot read our localStorage, and cannot
touch the DOM of the host page. This is enforced by the attribute, not
by CSP response headers — which matters because GitHub Pages cannot set
response headers.

Frames:

```js
// host → frame
{ type: 'run', id, code, input }

// frame → host
{ type: 'ready', id: null }
{ type: 'log',  id, args: [serializable] }
{ type: 'done', id, ok: true,  result }
{ type: 'done', id, ok: false, error: string }
```

Rules:

- The host ignores any message whose `id` does not match the pending
  run, and any message arriving after `done`.
- The contract for generated code is a **function body** that receives an
  `input` object and returns a value. The frame wraps it accordingly.
- `timeoutMs` is a hard deadline enforced host-side: on expiry the host
  removes the iframe entirely (an infinite loop cannot be interrupted
  from outside) and resolves `{ ok: false, error: 'timeout' }`.
- `logs` are captured `console.*` calls, serialized in the frame before
  crossing the boundary — structured-clone cannot carry arbitrary
  objects, so the frame stringifies.
- Return values must be structured-cloneable. Anything else surfaces as
  an error rather than a silent `undefined`.
