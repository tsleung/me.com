---
created: 2026-07-26
updated: 2026-07-27
---

# deep-space — requirements

## What it is

A static, client-side PWA at `docs/apps/deep-space/` that helps a player
solve the puzzle game **"The Message from Deep Space"** (Steam 4080030).
Setting: 1973. You are the mission Translator, reconstructing an alien
language from math and science upward — numeral system → arithmetic →
pattern → geometry → scientific concepts — over 30+ hours, so expect
*many* levels. The game is **bidirectional**: you decode incoming
transmissions *and* compose outgoing replies, and a correct reply is what
elicits the next message.

Primary user: Terran's dad, playing the game on one desktop with this app
open beside it.

The load-bearing constraint: **we cannot read the game's state.**
Everything the app knows is inferred from pixels plus the player's own
commentary. So the loop is:

1. Paste a screenshot into the app.
2. Drop numbered markers on it and type a note per marker, plus a
   free-text note for the level.
3. One pass of two LLM calls — a KB-free perception call over the image,
   then an interpretation call over that reading plus the accumulated
   knowledge base.
4. Back comes a reading, hypotheses with confidence, a proposed move, a
   proposed reply, and proposed knowledge-base ops.
5. The user accepts or rejects each op. Accepted ops append to a local
   op log; the knowledge base is the fold over that log and seeds every
   subsequent level.

The compounding value is the knowledge base, not any single call.

## Deployment status

**Public.** Single copy under `docs/apps/deep-space/` — no `apps/`
mirror (bayes/spread precedent). It ships to terranleung.com on every
push to `main` via the `me.com` deploy target.

It is **linked from the terranleung.com homepage** as of 2026-07-27,
once it had been used and tested in real play. Before that it shipped
unlinked, which was never the CLAUDE.md rule-4 "deployed but hidden"
state — rule 4 forbids using unlinked-ness as a *privacy mechanism*, and
nothing here was ever private. Nothing sensitive ships: the user's Gemini
API key lives only in their own browser's IndexedDB and is sent only to
`generativelanguage.googleapis.com`.

The app footer links a **documentation bundle**
(`deep-space-docs.zip`) built by `scripts/build-deep-space-docs.sh` from
`notes/deep-space/`. It carries architecture, methodology, requirements,
protocol and process, plus a README that orders them. `prompts.md` (the
raw verbatim prompt log) and the internal pre-implementation review are
deliberately **excluded** — they stay in `notes/`. The bundle is committed
rather than generated at deploy time, because this repo has no build step;
re-run the script whenever those docs change.

## v1 features

0. **Key gate.** Nothing in the app works without a Gemini API key, so
   the console is not rendered at all until there is one — the gate and
   the console both start hidden and boot reveals exactly one, so neither
   flashes. The gate explains what the key is for, links to
   [Google AI Studio → API keys](https://aistudio.google.com/app/apikey),
   and verifies the key against ListModels before opening the console. A
   network failure must not lock anyone out, so a rejected check offers
   "Use it anyway". Clearing the key in Settings puts the gate back.
0.5. **Adding the next level is always visible.** A "+ New level" button
   sits at the top of the sidebar at all times, and the paste hint stays
   on screen once levels exist, naming the number the next paste will
   become. The way in must not vanish after the first screen.
1. **Capture.** Clipboard paste (Ctrl/Cmd+V) is the primary path; file
   drop and a file picker; and a "Capture screen" button using
   `getDisplayMedia`.
2. **Level list sidebar** — thumbnail, level number, solved/unsolved.
3. **Annotation** — click the screenshot to drop a numbered marker and
   type a note for it; plus a free-text note for the level as a whole.
4. **Settings pane** — Gemini API key (IndexedDB only), model name field
   defaulting to `gemini-3.5-flash`, a "check model" button that
   validates against ListModels and reports failure as a UI message,
   storage usage from `StorageManager.estimate()`, a "make storage
   persistent" button, and export/import of a bundle.
5. **Analyze** — the map call (cached by image hash + model + prompt
   version) then the answer call. Shows the reading, hypotheses with
   confidence, proposed reply, proposed move. **From the second level
   onward this runs automatically on paste** (setting `autoAnalyze`,
   default on, with a Stop button). Level 1 never auto-runs: nothing is
   remembered yet, and no call should be spent before the user has seen
   the app work. While a run is in flight the Analyze and Re-run buttons
   disable and relabel themselves rather than raising an error on a
   second press; Stop is the way out.
5.5. **Standing instructions** — a persistent block of player guidance
   (`standingNotes`) sent with every answer prompt, editable in Settings.
   "Apply this note to every level" promotes the current level note into
   it in one press and clears it from the level so it is not sent twice.
   This exists because the same correction was being retyped every level;
   anything repeated belongs in the prompt, not in the player's fingers.
5.6. **Watch it work** — the answer streams token by token via
   `:streamGenerateContent`, with any reasoning the model exposes shown
   separately, and the exact prompt sent for BOTH calls is displayed
   under the answer. An app wrapped around someone else's model is
   undiagnosable without this.
5.7. **Debug report** — one file per screen holding everything needed to
   work out why an answer came back as it did: the exact prompt text for
   both calls, the raw reply and any reasoning, the parsed answer, the
   knowledge base as it stood, the validator's verdicts, the complaints
   sent, recent errors, and the settings that shaped the run. The picture
   is opt-in (31 KB with it, 21 KB without, on a typical screen). The API
   key is never in it — stripped by field name *and* by pattern, because
   Google echoes the key back inside some error messages.
5.8. **Help tab — a user guide inside the app.** Written for someone who
   wants to *use* it, not build it: setup once, the loop every level, how
   to read an answer, pointing at something with markers, what to do when
   the answer is wrong, what each of the three run buttons costs, what it
   remembers and why to be strict about it, troubleshooting, and keeping
   backups. Reachable **behind the key gate** — someone without a key yet
   is the person most likely to want instructions — where it replaces the
   gate rather than hiding behind it, with "Screen" as the way back.
5.9. **The knowledge base is explained in the Help tab, in user terms.**
   Three sections — *How the knowledge base works*, *When two entries
   disagree*, *What actually gets sent* — covering: the shape of an entry
   (kind, subject, confidence, level); the append-only log and why
   *Rebuild from history* and *Undo the last change* are therefore safe;
   near-duplicate suppression, unapplied ops, and field trimming; what a
   disagreement is and why `subject` must name a concept rather than a
   value; that withdrawn entries leave the prompt but not the history;
   the `kbMax` send cap and its confidence-then-recency ranking; and
   *Run without the knowledge base* as the check on whether any of it
   earns its keep. Stated without jargon — no "op", "fold", or
   "materialized view" reaches the user. The mechanics behind it are in
   `architecture.md` §KB; this section must not drift from `kb.js`.
6. **Op adjudication** — accept or reject each proposed op individually
   before it touches the op log; rejections and rewrites from
   `validateOps` are shown with their reasons.
7. **Knowledge-base view** — beliefs grouped by kind, provenance link
   back to the shot that produced each, a retract button, and a
   contradiction queue the user adjudicates.
8. **Three separate run buttons**, because they cost different things.
   **Analyze** reads the picture if needed, then answers. **Answer again,
   same picture** reuses the stored description — one answer call, no
   vision call; what you want after adding a note. **Read the picture
   again** goes back to the screenshot and re-describes it — one vision
   call, no answer; what you want after the prompts change. A reading made
   under an older prompt version or a different model is flagged in the
   level view, and Settings offers **Read every screen again**, which
   skips screens already current and can be stopped part-way.
9. **Run without KB toggle** — sends the answer call with an empty
   knowledge base, clearly labelled. This is the experiment that tests
   whether the KB actually compounds.
10. **Re-reduce** — re-fold the entire op log from scratch and report
    what changed.
11. **Code panel** — generated code shown read-only with a copy button, a
    "Run locally (sandboxed)" button backed by a sandboxed iframe, and a
    toggle to use Gemini's server-side code execution instead.

## How this gets built

After the first working build, the driver is **playing the game with the
app**. Findings from real sessions, and the feature changes they forced,
are logged in [`process.md`](process.md) under "Findings from play". Two
of the most important defects so far — the assistant spending its answer
on interface mechanics, and refusing to solve a puzzle because the
composer was not open — were invisible to the entire test suite and were
caught from a screenshot of the running app.

## Constraints

- **Self-contained.** No imports from `apps/_shared/` — the me.com deploy
  slice is `docs/` only, so `_shared` would 404 in production.
- No build step, no bundler, no npm dependency in the app. Native ES
  modules via `<script type="module">`.
- Pure logic (`kb.js`, `prompts.js`) is DOM-free, node-importable, and
  unit-tested by `__tests__/` inside the app directory, wired into
  `npm run validate`.
- **Map is KB-free.** The perception call never receives the knowledge
  base. See `protocol.md`; this is a protocol-level invariant, not a
  style preference.
- **Images are lossless PNG.** Thin-stroke glyph decoding is exactly
  where lossy compression eats the signal. The only derivative is a
  ~320px thumbnail for the level list.
- **Generated code runs in a sandboxed iframe** (`sandbox="allow-scripts"`,
  opaque origin). A same-origin Web Worker is not a sandbox — it can
  `fetch` and read IndexedDB including the API key.
- PWA scope is installability only: manifest plus a minimal service
  worker. No offline caching.

## Non-goals (explicitly out of scope for v1)

- File System Access folder mirror.
- Persistent solver library (stored decoders/encoders re-run across
  levels).
- Offline service-worker caching.
- Ranked-hypothesis UI beyond plain confidence text.
- Any server component. No backend, no proxy, no analytics.
- Conversational chat. Follow-up is "amend the notes and re-run," not a
  second turn.
